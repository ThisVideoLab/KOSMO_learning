package chap16.EX06.EX1;

public abstract class Meterial {
	
	public abstract void doPrinting();
	

}
